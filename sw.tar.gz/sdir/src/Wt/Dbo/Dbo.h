// This may look like C code, but it's really -*- C++ -*-
/*
 * Copyright (C) 2008 Emweb bvba, Kessel-Lo, Belgium.
 *
 * See the LICENSE file for terms of use.
 */
#ifndef WT_DBO_DBO_H_
#define WT_DBO_DBO_H_

#include <Wt/Dbo/Types.h>
#include <Wt/Dbo/Impl.h>

#endif // WT_DBO_H_
